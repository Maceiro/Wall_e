namespace WallE.Graphics
{
    public enum GraphicColors
    {
        Black,
        Blue, 
        Red,
        Yellow,
        Green,
        Cyan,
        Magenta,
        White,
        Gray

    }
}